#! /bin/bash

sudo rm /usr/local/include/usb_can.h
sudo rm /usr/local/lib/libuseb_fdcan.so
sudo rm /etc/udev/rules.d/usb_can.rules