import ctypes
from copy import deepcopy
from ctypes import *

import os



class FrameInfo(Structure):
    _fields_ = [("canID", c_uint32),
                ("frameType", c_uint8),
                ("dataLength", c_uint8)]

STANDARD: int = 0
EXTENDED: int = 1
CAN: int = 0
FDCAN: int = 1
FDCAN_500K = 0
FDCAN_1M = 1
FDCAN_2M = 2
FDCAN_4M = 3
FDCAN_0BYTES = 0
FDCAN_1BYTE = 1
FDCAN_2BYTES = 2
FDCAN_3BYTES = 3
FDCAN_4BYTES = 4
FDCAN_5BYTES = 5
FDCAN_6BYTES = 6
FDCAN_7BYTES = 7
FDCAN_8BYTES = 8
FDCAN_12BYTES = 9
FDCAN_16BYTES = 10
FDCAN_20BYTES = 11
FDCAN_24BYTES = 12
FDCAN_32BYTES = 13
FDCAN_48BYTES = 14
FDCAN_64BYTES = 15


class USB2FDCAN:
    def __init__(self, device_name:str):
        current_dir = os.path.dirname(os.path.abspath(__file__))
        try:
            self._so_lib = cdll.LoadLibrary(os.path.join(current_dir, "libusb_fdcan.so"))

            self._open_fun = self._so_lib.openUSBCAN
            self._open_fun.restype = c_int32
            self._open_fun.argtypes = [c_char_p]

            self._close_fun = self._so_lib.closeUSBCAN
            self._close_fun.restype = c_int32
            self._close_fun.argtypes = [c_int32]

            self._send_fun = self._so_lib.sendUSBCAN
            self._send_fun.restype = c_int32
            self._send_fun.argtypes = [c_int32, c_uint8, POINTER(FrameInfo), POINTER(c_uint8)]

            self._read_fun = self._so_lib.readUSBCAN
            self._read_fun.restype = c_int32
            self._read_fun.argtypes = [c_int32, POINTER(c_uint8), POINTER(FrameInfo), POINTER(c_uint8), c_int32]

            self._config_fun = self._so_lib.configUSBCAN
            self._config_fun.restype = c_int32
            self._config_fun.argtypes = [c_int32, c_uint8, c_uint8, c_uint8, c_uint8]

        except Exception as e:
            raise ImportError(e)
        device_name = device_name.encode()
        self._c_handler = self._open_fun(c_char_p(device_name))

    def send_usbcan(self, channel: int, info: FrameInfo, data: bytearray):
        data_c = (ctypes.c_uint8 * 8)(*data)

        return self._so_lib.sendUSBCAN(self._c_handler, c_uint8(channel), pointer(info), data_c)

    def read_usbcan(self, timeout: int = 1e7):
        channel_c = c_uint8()
        info = FrameInfo()
        data_c = (ctypes.c_uint8 * 8)()
        timeout = int(timeout)
        ret = self._so_lib.readUSBCAN(self._c_handler, channel_c, pointer(info), data_c, c_int32(timeout))
        print(ret)
        if ret < 0:
            return None
        else:
            return channel_c.value, deepcopy(info), bytearray(data_c)

    def config_usbcan(self, channel: int, can_type: int, nominal_speed: int, data_speed: int):
        return self._so_lib.configUSBCAN(self._c_handler, c_uint8(channel), c_uint8(can_type), c_uint8(nominal_speed), c_uint8(data_speed))

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self._so_lib.closeUSBCAN(self._c_handler)
