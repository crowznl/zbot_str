from setuptools import setup, find_packages

setup(
    name="pyusb2fdcan",
    version="1.0",
    author="soulde",
    description="Python SDK for DingLAB USB2FDCAN",
    packages=find_packages(),
    install_requires=[],

)
